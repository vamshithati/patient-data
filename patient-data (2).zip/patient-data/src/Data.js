export const UserData = [
  {
    id: 1,
    year: "Oct,2023",
    systolic: 120,
    diastolic: 110,
  },
  {
    id: 2,
    year: "Nov,2023",
    systolic: 118,
    diastolic: 63,
  },
  {
    id: 3,
    year: "Dec,2023",
    systolic: 160,
    diastolic: 109,
  },
  {
    id: 4,
    year: "Jan,2024",
    systolic: 117,
    diastolic: 95,
  },
  {
    id: 5,
    year: "Feb,2024",
    systolic: 150,
    diastolic: 50,
  },
  {
    id: 6,
    year: "Mar,2024",
    systolic: 159,
    diastolic: 79,
  },
];
